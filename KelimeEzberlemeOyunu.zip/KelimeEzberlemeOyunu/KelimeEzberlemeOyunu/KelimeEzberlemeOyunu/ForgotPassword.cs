﻿namespace KelimeEzberlemeOyunu;

public partial class ForgotPassword : Form
{
    public string _newPassword;
    public ForgotPassword(User user)
    {
        InitializeComponent();
    }

    private void btnSave_Click(object sender, EventArgs e)
    {
        _newPassword = txtNewPassword.Text;

        DialogResult = DialogResult.OK;

        this.Close();
    }
}
