﻿namespace KelimeEzberlemeOyunu;

public partial class Report : Form
{
    public Report()
    {
        InitializeComponent();
    }

    private void LoadReport()
    {
        using (var context = new WordLearningContext())
        {
            var userId = CurrentUser.User.UserID;
            var report = context.UserWords
                                .Where(uw => uw.UserID == userId)
                                .GroupBy(uw => uw.Word)
                                .Select(g => new
                                {
                                    Word = g.Key.EnglishWord,
                                    CorrectAnswers = g.Sum(uw => uw.CorrectAnswers) + 1,
                                    LastCorrectDate = g.Max(uw => uw.LastCorrectAnswerDate)
                                })
                                .ToList();

            dataGridViewReport.DataSource = report;
        }
    }

    private void Report_Load(object sender, EventArgs e)
    {
        LoadReport();
    }
}
