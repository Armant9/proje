﻿namespace KelimeEzberlemeOyunu
{
    partial class AddWord
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            txtEnglishWord = new TextBox();
            txtTurkishMeaning = new TextBox();
            txtSentenceExample = new TextBox();
            btnSound = new Button();
            btnAddWord = new Button();
            btnCancel = new Button();
            btnImage = new Button();
            openFileDialogImage = new OpenFileDialog();
            openFileDialogAudio = new OpenFileDialog();
            pictureBox1 = new PictureBox();
            txtAudio = new TextBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(53, 37);
            label1.Name = "label1";
            label1.Size = new Size(73, 15);
            label1.TabIndex = 0;
            label1.Text = "İngilizce söz:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(44, 66);
            label2.Name = "label2";
            label2.Size = new Size(84, 15);
            label2.TabIndex = 1;
            label2.Text = "Türkçe anlamı:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(44, 95);
            label3.Name = "label3";
            label3.Size = new Size(82, 15);
            label3.TabIndex = 2;
            label3.Text = "Cümle örneği:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(71, 129);
            label4.Name = "label4";
            label4.Size = new Size(42, 15);
            label4.TabIndex = 3;
            label4.Text = "Resim:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(86, 159);
            label5.Name = "label5";
            label5.Size = new Size(27, 15);
            label5.TabIndex = 4;
            label5.Text = "Ses:";
            // 
            // txtEnglishWord
            // 
            txtEnglishWord.Location = new Point(132, 34);
            txtEnglishWord.Name = "txtEnglishWord";
            txtEnglishWord.Size = new Size(100, 23);
            txtEnglishWord.TabIndex = 5;
            // 
            // txtTurkishMeaning
            // 
            txtTurkishMeaning.Location = new Point(132, 63);
            txtTurkishMeaning.Name = "txtTurkishMeaning";
            txtTurkishMeaning.Size = new Size(100, 23);
            txtTurkishMeaning.TabIndex = 6;
            // 
            // txtSentenceExample
            // 
            txtSentenceExample.Location = new Point(132, 92);
            txtSentenceExample.Name = "txtSentenceExample";
            txtSentenceExample.Size = new Size(100, 23);
            txtSentenceExample.TabIndex = 7;
            // 
            // btnSound
            // 
            btnSound.Location = new Point(132, 159);
            btnSound.Name = "btnSound";
            btnSound.Size = new Size(100, 23);
            btnSound.TabIndex = 9;
            btnSound.Text = "Ekle";
            btnSound.UseVisualStyleBackColor = true;
            btnSound.Click += btnSound_Click;
            // 
            // btnAddWord
            // 
            btnAddWord.Location = new Point(44, 217);
            btnAddWord.Name = "btnAddWord";
            btnAddWord.Size = new Size(100, 23);
            btnAddWord.TabIndex = 10;
            btnAddWord.Text = "Sözü Ekle";
            btnAddWord.UseVisualStyleBackColor = true;
            btnAddWord.Click += btnAddWord_Click;
            // 
            // btnCancel
            // 
            btnCancel.Location = new Point(169, 217);
            btnCancel.Name = "btnCancel";
            btnCancel.Size = new Size(100, 23);
            btnCancel.TabIndex = 11;
            btnCancel.Text = "İptal";
            btnCancel.UseVisualStyleBackColor = true;
            btnCancel.Click += btnCancel_Click;
            // 
            // btnImage
            // 
            btnImage.Location = new Point(132, 125);
            btnImage.Name = "btnImage";
            btnImage.Size = new Size(100, 23);
            btnImage.TabIndex = 8;
            btnImage.Text = "Ekle";
            btnImage.UseVisualStyleBackColor = true;
            btnImage.Click += btnImage_Click;
            // 
            // openFileDialogImage
            // 
            openFileDialogImage.FileName = "openFileDialog1";
            // 
            // openFileDialogAudio
            // 
            openFileDialogAudio.FileName = "openFileDialog1";
            // 
            // pictureBox1
            // 
            pictureBox1.Location = new Point(292, 34);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(241, 110);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 12;
            pictureBox1.TabStop = false;
            // 
            // txtAudio
            // 
            txtAudio.Location = new Point(292, 160);
            txtAudio.Name = "txtAudio";
            txtAudio.Size = new Size(241, 23);
            txtAudio.TabIndex = 13;
            // 
            // AddWord
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(581, 262);
            Controls.Add(txtAudio);
            Controls.Add(pictureBox1);
            Controls.Add(btnCancel);
            Controls.Add(btnAddWord);
            Controls.Add(btnSound);
            Controls.Add(btnImage);
            Controls.Add(txtSentenceExample);
            Controls.Add(txtTurkishMeaning);
            Controls.Add(txtEnglishWord);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "AddWord";
            ShowIcon = false;
            StartPosition = FormStartPosition.CenterScreen;
            Text = "AddWord";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private TextBox txtEnglishWord;
        private TextBox txtTurkishMeaning;
        private TextBox txtSentenceExample;
        private Button btnSound;
        private Button btnAddWord;
        private Button btnCancel;
        private Button btnImage;
        private OpenFileDialog openFileDialogImage;
        private OpenFileDialog openFileDialogAudio;
        private PictureBox pictureBox1;
        private TextBox txtAudio;
    }
}