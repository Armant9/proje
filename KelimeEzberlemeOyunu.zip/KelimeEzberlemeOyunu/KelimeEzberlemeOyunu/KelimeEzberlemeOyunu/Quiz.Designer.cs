﻿namespace KelimeEzberlemeOyunu
{
    partial class Quiz
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            btnSubmit = new Button();
            txtCevap = new TextBox();
            label2 = new Label();
            cbSoru = new ComboBox();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(38, 57);
            label1.Name = "label1";
            label1.Size = new Size(42, 20);
            label1.TabIndex = 0;
            label1.Text = "Soru:";
            // 
            // btnSubmit
            // 
            btnSubmit.Location = new Point(376, 161);
            btnSubmit.Margin = new Padding(3, 4, 3, 4);
            btnSubmit.Name = "btnSubmit";
            btnSubmit.Size = new Size(86, 31);
            btnSubmit.TabIndex = 2;
            btnSubmit.Text = "Onayla";
            btnSubmit.UseVisualStyleBackColor = true;
            btnSubmit.Click += btnSubmit_Click;
            // 
            // txtCevap
            // 
            txtCevap.Location = new Point(84, 88);
            txtCevap.Margin = new Padding(3, 4, 3, 4);
            txtCevap.Name = "txtCevap";
            txtCevap.Size = new Size(378, 27);
            txtCevap.TabIndex = 4;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(32, 92);
            label2.Name = "label2";
            label2.Size = new Size(53, 20);
            label2.TabIndex = 3;
            label2.Text = "Cevap:";
            // 
            // cbSoru
            // 
            cbSoru.FormattingEnabled = true;
            cbSoru.Location = new Point(86, 57);
            cbSoru.Name = "cbSoru";
            cbSoru.Size = new Size(376, 28);
            cbSoru.TabIndex = 5;
            // 
            // Quiz
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(502, 223);
            Controls.Add(cbSoru);
            Controls.Add(txtCevap);
            Controls.Add(label2);
            Controls.Add(btnSubmit);
            Controls.Add(label1);
            Margin = new Padding(3, 4, 3, 4);
            Name = "Quiz";
            ShowIcon = false;
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Quiz";
            Load += Quiz_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Button btnSubmit;
        private TextBox txtCevap;
        private Label label2;
        private ComboBox cbSoru;
    }
}