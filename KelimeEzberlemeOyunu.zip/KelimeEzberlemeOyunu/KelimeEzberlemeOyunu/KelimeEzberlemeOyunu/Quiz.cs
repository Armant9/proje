﻿using Microsoft.Data.SqlClient;

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KelimeEzberlemeOyunu
{
    public partial class Quiz : Form
    {
        private string connectionString = "Data Source=localhost\\SQLEXPRESS;Database=WordLearning;User Id=sa;Password=Qwerty1;TrustServerCertificate=True;";


        public Quiz()
        {
            InitializeComponent();
        }

        public List<Word> GetWordsForQuiz(string userID)
        {
            List<Word> words = new List<Word>();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT * FROM Words WHERE UserID = @UserID";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@UserID", userID);
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        Word word = new Word
                        {
                            WordID = Convert.ToInt32(reader["WordID"]),
                            EnglishWord = reader["EnglishWord"].ToString(),
                            TurkishMeaning = reader["TurkishMeaning"].ToString(),
                            SentenceExamples = reader["SentenceExamples"].ToString(),
                            Image = reader["Image"].ToString(),
                            Audio = reader["Audio"].ToString()
                        };
                        words.Add(word);
                    }
                }
            }

            return words;
        }

        public void ProcessQuizResult(string userID, int wordID, bool isCorrect)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "UPDATE UserWords SET IsCorrect = @IsCorrect, LastQuizDate = GETDATE() WHERE UserID = @UserID AND WordID = @WordID";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@UserID", userID);
                    command.Parameters.AddWithValue("@WordID", wordID);
                    command.Parameters.AddWithValue("@IsCorrect", isCorrect);
                    connection.Open();
                    command.ExecuteNonQuery();
                }
            }
        }

        private void Quiz_Load(object sender, EventArgs e)
        {
            LoadQuiz();
            
        }

        private void LoadQuiz()
        {
            using (var context = new WordLearningContext())
            {
                var userId = CurrentUser.User.UserID;
                var words = context.UserWords
                                   .Where(uw => uw.UserID == userId && uw.CorrectAnswers < 6)
                                   .Select(uw => uw.Word)
                                   .Take(context.Settings.Single(s => s.UserID == userId).WordsPerTest)
                                   .ToList();

                foreach (var item in words)
                {

                    cbSoru.Items.Add(item.EnglishWord);
                }
              
            }
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            if (txtCevap.Text == "Elma")
            {
                MessageBox.Show("Dogru cevap!");
            }
        }
    }
}
