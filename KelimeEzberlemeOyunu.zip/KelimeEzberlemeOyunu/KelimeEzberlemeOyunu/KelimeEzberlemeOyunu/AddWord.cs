﻿namespace KelimeEzberlemeOyunu;

public partial class AddWord : Form
{
    public AddWord()
    {
        InitializeComponent();
    }

    private void btnAddWord_Click(object sender, EventArgs e)
    {
        string imagePath = pictureBox1.Tag?.ToString();
        string audioPath = txtAudio.Text;

        try
        {
            using (var context = new WordLearningContext())
            {
                var word = new Word
                {
                    EnglishWord = txtEnglishWord.Text,
                    TurkishMeaning = txtTurkishMeaning.Text,
                    SentenceExamples = txtSentenceExample.Text,
                    Image = imagePath,
                    Audio = audioPath
                };

                context.Words.Add(word);
                context.SaveChanges();
                MessageBox.Show("Kelime eklendi!");
            }
        }
        catch (Exception ex)
        {
            MessageBox.Show("Hata: " + ex.Message);
        }
    }

    private void btnImage_Click(object sender, EventArgs e)
    {
        OpenFileDialog openFileDialog = new OpenFileDialog();
        openFileDialog.Filter = "Resim Dosyaları|*.jpg;*.jpeg;*.png;*.bmp";
        if (openFileDialog.ShowDialog() == DialogResult.OK)
        {
            pictureBox1.Image = Image.FromFile(openFileDialog.FileName);
            pictureBox1.Tag = openFileDialog.FileName;
        }
    }

    private void btnSound_Click(object sender, EventArgs e)
    {
        OpenFileDialog openFileDialog = new OpenFileDialog();
        openFileDialog.Filter = "Ses Dosyaları|*.mp3;*.wav";
        if (openFileDialog.ShowDialog() == DialogResult.OK)
        {
            txtAudio.Text = openFileDialog.FileName;
        }
    }

    private void btnCancel_Click(object sender, EventArgs e)
    {
        this.Close();
    }
}
