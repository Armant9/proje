﻿using Microsoft.EntityFrameworkCore;

namespace KelimeEzberlemeOyunu;

public class WordLearningContext : DbContext
{
    public DbSet<User> Users { get; set; }
    public DbSet<Word> Words { get; set; }
    public DbSet<UserWord> UserWords { get; set; }
    public DbSet<Setting> Settings { get; set; }
    public DbSet<TestResult> TestResults { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        optionsBuilder.UseSqlServer("Data Source=SPARE-LT\\MSSQLSERVER02;Database=WordLearning;User Id=sa;Password=Qwerty1;TrustServerCertificate=True;");
    }
}

public class User
{
    public int UserID { get; set; }
    public string Username { get; set; }
    public string Password { get; set; }
    public string Email { get; set; }
}

public static class CurrentUser
{
    public static User User { get; set; }
}

public class Word
{
    public int WordID { get; set; }
    public string EnglishWord { get; set; }
    public string TurkishMeaning { get; set; }
    public string SentenceExamples { get; set; }
    public string Image { get; set; }
    public string Audio { get; set; }
}

public class UserWord
{
    public int UserWordID { get; set; }
    public int UserID { get; set; }
    public User User { get; set; }
    public int WordID { get; set; }
    public Word Word { get; set; }
    public int CorrectAnswers { get; set; }
    public DateTime? LastCorrectAnswerDate { get; set; }
}

public class Setting
{
    public int SettingID { get; set; }
    public int UserID { get; set; }
    public User User { get; set; }
    public int WordsPerTest { get; set; }
}

public class TestResult
{
    public int TestResultID { get; set; }
    public int UserID { get; set; }
    public User User { get; set; }
    public DateTime TestDate { get; set; }
    public int CorrectAnswers { get; set; }
    public int IncorrectAnswers { get; set; }
}