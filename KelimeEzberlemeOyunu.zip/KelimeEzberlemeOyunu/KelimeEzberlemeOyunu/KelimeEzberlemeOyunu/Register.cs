﻿namespace KelimeEzberlemeOyunu;

public partial class Register : Form
{
    public Register()
    {
        InitializeComponent();
    }

    private void btnAccept_Click(object sender, EventArgs e)
    {
        try
        {
            using (var context = new WordLearningContext())
            {
                var user = new User
                {
                    Username = txtName.Text,
                    Password = txtPassword.Text,
                    Email = txtMail.Text
                };
                context.Users.Add(user);
                context.SaveChanges();
                MessageBox.Show("Başarıyla kayıt olundu!");
            }
        }
        catch (Exception ex)
        {
            MessageBox.Show("Hata: " + ex.Message);
        }

        this.Close();
    }

    private void btnCancel_Click(object sender, EventArgs e)
    {
        this.Close();
    }
}
