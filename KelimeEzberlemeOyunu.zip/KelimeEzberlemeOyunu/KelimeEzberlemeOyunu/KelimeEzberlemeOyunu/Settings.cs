﻿namespace KelimeEzberlemeOyunu;

public partial class Settings : Form
{
    public Settings()
    {
        InitializeComponent();
    }

    private void btnAccept_Click(object sender, EventArgs e)
    {
        try
        {
            using (var context = new WordLearningContext())
            {
                var settings = context.Settings.SingleOrDefault(s => s.UserID == CurrentUser.User.UserID);

                if (settings == null)
                {
                    settings = new Setting
                    {
                        UserID = CurrentUser.User.UserID,
                        WordsPerTest = int.Parse(txtWordsPerTest.Text)
                    };
                    context.Settings.Add(settings);
                }
                else
                {
                    settings.WordsPerTest = int.Parse(txtWordsPerTest.Text);
                }
                context.SaveChanges();
                MessageBox.Show("Ayarlar kaydedildi");
            }
        }
        catch (Exception ex)
        {
            MessageBox.Show("Hata: " + ex.Message);
        }
    }

    private void btnCancel_Click(object sender, EventArgs e)
    {
        this.Close();
    }
}
