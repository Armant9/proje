namespace KelimeEzberlemeOyunu
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            while (true)
            {
                Login login = new Login();
                if (login.ShowDialog() == DialogResult.OK)
                {
                    break;
                }
                else
                {

                }
            }
        }

        private void btnAddWord_Click(object sender, EventArgs e)
        {
            AddWord addWord = new AddWord();
            addWord.Show();
        }

        private void btnQuiz_Click(object sender, EventArgs e)
        {
            Quiz quiz = new Quiz();
            quiz.Show();
        }

        private void btnReport_Click(object sender, EventArgs e)
        {
            Report report = new Report();
            report.Show();
        }

        private void btnSettings_Click(object sender, EventArgs e)
        {
            Settings settings = new Settings();
            settings.Show();
        }
    }
}
