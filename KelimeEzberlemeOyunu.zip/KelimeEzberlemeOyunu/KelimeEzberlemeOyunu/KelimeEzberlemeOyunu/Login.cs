﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KelimeEzberlemeOyunu
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            using (var context = new WordLearningContext())
            {
                var user = context.Users
                                  .FirstOrDefault(u => u.Username == txtUsername.Text
                                                   && u.Password == txtPassword.Text);
                if (user != null)
                {
                    CurrentUser.User = user;
                    MessageBox.Show("Giriş Başarılı");
                    DialogResult = DialogResult.OK;
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Yanlış kullanıcı adı veya şifre");
                    DialogResult = DialogResult.Cancel;
                }
            }
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            Register register = new Register();
            register.Show();
        }

        private void btnForgetPassword_Click(object sender, EventArgs e)
        {
            using (var context = new WordLearningContext())
            {
                string username = txtUsername.Text;

                var user = context.Users.FirstOrDefault(u => u.Username == username);

                if (user != null)
                {
                    using (var forgotPassword = new ForgotPassword(user))
                    {
                        if (forgotPassword.ShowDialog() == DialogResult.OK)
                        {
                            user.Password = forgotPassword._newPassword;
                            context.SaveChanges();
                            MessageBox.Show("Şifreniz başarıyla güncellendi.");
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Böyle bir kullanıcı bulunamadı. Lütfen geçerli bir kullanıcı adı girin.");
                }
            }
        }
    }
}
