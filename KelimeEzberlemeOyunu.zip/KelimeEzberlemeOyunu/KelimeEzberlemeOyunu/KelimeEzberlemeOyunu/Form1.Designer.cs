﻿namespace KelimeEzberlemeOyunu
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnAddWord = new Button();
            label1 = new Label();
            btnQuiz = new Button();
            btnReport = new Button();
            btnSettings = new Button();
            SuspendLayout();
            // 
            // btnAddWord
            // 
            btnAddWord.Location = new Point(76, 73);
            btnAddWord.Name = "btnAddWord";
            btnAddWord.Size = new Size(134, 50);
            btnAddWord.TabIndex = 0;
            btnAddWord.Text = "Kelime Ekle";
            btnAddWord.UseVisualStyleBackColor = true;
            btnAddWord.Click += btnAddWord_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(113, 25);
            label1.Name = "label1";
            label1.Size = new Size(64, 25);
            label1.TabIndex = 1;
            label1.Text = "Menü";
            // 
            // btnQuiz
            // 
            btnQuiz.Location = new Point(76, 129);
            btnQuiz.Name = "btnQuiz";
            btnQuiz.Size = new Size(134, 50);
            btnQuiz.TabIndex = 2;
            btnQuiz.Text = "Sınav";
            btnQuiz.UseVisualStyleBackColor = true;
            btnQuiz.Click += btnQuiz_Click;
            // 
            // btnReport
            // 
            btnReport.Location = new Point(76, 185);
            btnReport.Name = "btnReport";
            btnReport.Size = new Size(134, 50);
            btnReport.TabIndex = 3;
            btnReport.Text = "Rapor";
            btnReport.UseVisualStyleBackColor = true;
            btnReport.Click += btnReport_Click;
            // 
            // btnSettings
            // 
            btnSettings.Location = new Point(76, 241);
            btnSettings.Name = "btnSettings";
            btnSettings.Size = new Size(134, 50);
            btnSettings.TabIndex = 4;
            btnSettings.Text = "Ayarlar";
            btnSettings.UseVisualStyleBackColor = true;
            btnSettings.Click += btnSettings_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(289, 332);
            Controls.Add(btnSettings);
            Controls.Add(btnReport);
            Controls.Add(btnQuiz);
            Controls.Add(label1);
            Controls.Add(btnAddWord);
            Name = "Form1";
            ShowIcon = false;
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Kelime Ezberleme Oyunu";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnAddWord;
        private Label label1;
        private Button btnQuiz;
        private Button btnReport;
        private Button btnSettings;
    }
}
